import OnePersonManyVideo from "./pages/OnePersonManyVideo"


const App = () => {
  return (
    <div>
      <OnePersonManyVideo></OnePersonManyVideo>
    </div>
  )
}

export default App