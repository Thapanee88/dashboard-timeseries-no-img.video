export interface IDropdownImg {
  value: number;
  label: string;
  img?: string;
}